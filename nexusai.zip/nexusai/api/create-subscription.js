// api/create-subscription.js
// Vercel Serverless Function — crée un abonnement Stripe à 120€/mois

const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

const PRICE_ID = process.env.STRIPE_PRICE_ID; // ID du prix créé dans Stripe Dashboard

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const { email, company } = req.body;
  if (!email || !company) return res.status(400).json({ error: 'Email et entreprise requis' });

  try {
    // 1. Créer ou récupérer le client Stripe
    const existing = await stripe.customers.list({ email, limit: 1 });
    let customer;
    if (existing.data.length > 0) {
      customer = existing.data[0];
    } else {
      customer = await stripe.customers.create({
        email,
        name: company,
        metadata: { company }
      });
    }

    // 2. Créer l'abonnement avec paiement immédiat
    const subscription = await stripe.subscriptions.create({
      customer: customer.id,
      items: [{ price: PRICE_ID }],
      payment_behavior: 'default_incomplete',
      payment_settings: { save_default_payment_method: 'on_subscription' },
      expand: ['latest_invoice.payment_intent'],
    });

    const clientSecret = subscription.latest_invoice.payment_intent.client_secret;

    res.status(200).json({ clientSecret, subscriptionId: subscription.id });

  } catch (err) {
    console.error('Stripe error:', err.message);
    res.status(500).json({ error: err.message });
  }
};
