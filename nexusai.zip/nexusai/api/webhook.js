// api/webhook.js
// Vercel Serverless Function — gère les événements Stripe (paiement réussi/échoué)

const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

// Désactiver le body parser pour lire le raw body (requis par Stripe)
export const config = { api: { bodyParser: false } };

async function getRawBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', chunk => chunks.push(chunk));
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).end();

  const rawBody = await getRawBody(req);
  const sig = req.headers['stripe-signature'];

  let event;
  try {
    event = stripe.webhooks.constructEvent(rawBody, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error('Webhook signature error:', err.message);
    return res.status(400).json({ error: `Webhook Error: ${err.message}` });
  }

  switch (event.type) {

    case 'invoice.payment_succeeded': {
      const invoice = event.data.object;
      const customerId = invoice.customer;
      const customer = await stripe.customers.retrieve(customerId);
      console.log(`✅ Paiement reçu — ${customer.email} — ${invoice.amount_paid / 100}€`);
      // TODO: activer l'accès dans votre base de données
      // await db.activateAccess(customer.email);
      break;
    }

    case 'invoice.payment_failed': {
      const invoice = event.data.object;
      const customer = await stripe.customers.retrieve(invoice.customer);
      console.log(`❌ Paiement échoué — ${customer.email}`);
      // TODO: désactiver l'accès et envoyer un email de relance
      // await db.suspendAccess(customer.email);
      break;
    }

    case 'customer.subscription.deleted': {
      const sub = event.data.object;
      const customer = await stripe.customers.retrieve(sub.customer);
      console.log(`🚫 Résiliation — ${customer.email}`);
      // TODO: désactiver définitivement l'accès
      // await db.revokeAccess(customer.email);
      break;
    }

    case 'customer.subscription.created': {
      const sub = event.data.object;
      const customer = await stripe.customers.retrieve(sub.customer);
      console.log(`🎉 Nouvel abonné — ${customer.email}`);
      // TODO: envoyer email de bienvenue + créer le compte
      break;
    }

    default:
      console.log(`Événement non géré: ${event.type}`);
  }

  res.status(200).json({ received: true });
};
