# NexusAI — Déploiement sur Vercel

## Structure du projet
```
nexusai/
├── public/
│   └── index.html          ← Landing page + formulaire Stripe
├── api/
│   ├── create-subscription.js  ← Crée l'abonnement Stripe
│   └── webhook.js              ← Gère les événements Stripe
├── package.json
├── vercel.json
└── README.md
```

---

## Étape 1 — Créer le produit dans Stripe Dashboard

1. Aller sur https://dashboard.stripe.com/products
2. Cliquer "Ajouter un produit"
3. Nom : "NexusAI Pro Entreprise"
4. Prix : 120,00 € — Récurrent — Mensuel
5. Copier l'ID du prix (commence par `price_...`)

---

## Étape 2 — Déployer sur Vercel

```bash
# Installer Vercel CLI
npm install -g vercel

# Dans le dossier du projet
cd nexusai
vercel

# Suivre les instructions (créer un compte si besoin)
```

---

## Étape 3 — Ajouter les variables d'environnement sur Vercel

Dans votre dashboard Vercel → Settings → Environment Variables :

| Variable | Valeur |
|----------|--------|
| `STRIPE_SECRET_KEY` | `sk_live_...` (votre clé secrète Stripe) |
| `STRIPE_PRICE_ID` | `price_...` (l'ID du prix créé à l'étape 1) |
| `STRIPE_WEBHOOK_SECRET` | `whsec_...` (voir étape 4) |

---

## Étape 4 — Configurer le webhook Stripe

1. Aller sur https://dashboard.stripe.com/webhooks
2. Cliquer "Ajouter un endpoint"
3. URL : `https://votre-projet.vercel.app/api/webhook`
4. Événements à écouter :
   - `invoice.payment_succeeded`
   - `invoice.payment_failed`
   - `customer.subscription.deleted`
   - `customer.subscription.created`
5. Copier le "Signing secret" (commence par `whsec_...`)
6. L'ajouter dans les variables d'environnement Vercel

---

## Étape 5 — Redéployer

```bash
vercel --prod
```

Votre site est en ligne ! Les clients peuvent s'abonner et vous recevez 120€/mois automatiquement.

---

## Test avant mise en production

Remplacer la clé publique dans index.html par `pk_test_...` et utiliser la carte de test Stripe :
- Numéro : `4242 4242 4242 4242`
- Date : n'importe quelle date future
- CVC : `123`
